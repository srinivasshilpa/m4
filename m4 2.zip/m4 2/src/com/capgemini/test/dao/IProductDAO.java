package com.capgemini.test.dao;

import java.util.List;

import com.capgemini.test.entities.Product;
import com.capgemini.test.exception.ProductException;

public interface IProductDAO 
{
	public Product removeProduct(int id) throws ProductException;

	public List<Product> getAllProducts() throws ProductException;
	
}
