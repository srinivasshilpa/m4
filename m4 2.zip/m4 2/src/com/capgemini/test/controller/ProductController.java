package com.capgemini.test.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;



import org.springframework.web.servlet.ModelAndView;







import com.capgemini.test.entities.Product;
import com.capgemini.test.exception.ProductException;
import com.capgemini.test.service.IProductService;




@Controller
public class ProductController {
	
	@Autowired
	private IProductService productService;

	public IProductService getProductService() {
		return productService;
	}

	public void setProductService(IProductService productService) {
		this.productService = productService;
	}
	
	@RequestMapping(value="/HomePage.html", method=RequestMethod.GET)
	public ModelAndView getHomePage()
	{
		try{
			List<Product> products=productService.getAllProducts();
			
			return new ModelAndView("HomePage", "products", products);
		}
		catch(ProductException e)
		{
			return new ModelAndView("ErrorPage", "errMsg", "Something went wrong while trying to fetch all products. Reason:"+e.getMessage());
		}	
	}
	
	
	
	@RequestMapping(value="/RemoveProductByID.html", method=RequestMethod.GET)
	public ModelAndView removeProductById(@RequestParam("productId") int id, Model model)
	{
		try{
			Product product=productService.removeProduct(id);
			List<Product> products=productService.getAllProducts();
			return new ModelAndView("HomePage", "products", products);
			}
		catch(ProductException e)
		{
			return new ModelAndView("ErrorPage", "errMsg", "Something went wrong while trying to fetch all products. Reason:"+e.getMessage());		}
	}
	
	
}